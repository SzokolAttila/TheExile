﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace TheExileBasic
{
    class Fighter
    {
        public string Temp { get; set; }
        public int Range { get; set; }
        public int[] Pos { get; set; }
        public int attack { get; set; }
        public int HP { get; set; }
        public int XP { get; set; }

        public string[][] Move (string direction, string[][] room)
        {
            room[this.Pos[0]][this.Pos[1]] = this.Temp;

            switch (direction)
            {
                case "s":
                    if (this.Pos[0] < room.Length - 1 && room[Pos[0] + 1][Pos[1]] != "M")
                        this.Pos[0]++;
                    break;
                case "w":
                    if (this.Pos[0] > 0 && room[Pos[0] - 1][Pos[1]] != "M")
                        this.Pos[0]--;
                    break;
                case "a":
                    if (this.Pos[1] > 0 && room[Pos[0]][Pos[1] - 1] != "M")
                        this.Pos[1]--;
                    break;
                case "d":
                    if (this.Pos[1] < room[Pos[0]].Length - 1 && room[Pos[0]][Pos[1] + 1] != "M")
                        this.Pos[1]++;
                    break;
                default:
                    break;
            }

            this.Temp = room[this.Pos[0]][this.Pos[1]];
            room[this.Pos[0]][this.Pos[1]] = "X";
            Console.Clear();

            return room;
        }

        public string View (string[][] room)
        {
            string screen = "";

            for (int i = -this.Range; i <= this.Range; i++)
            {
                for (int j = -this.Range; j <= this.Range; j++)
                {
                    if (this.Pos[0] + i >= 0 && this.Pos[0] + i < room.Length && this.Pos[1] + j >= 0 && this.Pos[1] + j < room[Pos[0]].Length && this.Pos[1] + j < room[Pos[0] + i].Length)
                        screen += room[this.Pos[0] + i][this.Pos[1] + j];
                    else screen += " ";
                }
                screen += "\n";
            }

            return screen;
        }
    }

    class Enemy
    {
        public int HP { get; set; }
        public int AP { get; set; }
        public string Name { get; set; }
        public int xp { get; set; }

        public int[] Combat(int fighterHp, int fighterAttack)
        {
            int currentHP = this.HP;
            while (true)
            {
                Console.Clear();
                Console.WriteLine("The Exile");
                Console.WriteLine("Now it's time to fight!");
                Console.WriteLine(this.Name+"\t\t\t\t"+"Your stats:\n"+currentHP+"/"+this.HP+"\t\t\t\t"+"Attack: "+fighterAttack+"\n\t\t\t\t\t"+fighterHp);
                Console.WriteLine("It's your turn");
                currentHP -= fighterAttack;
                if (currentHP<=0)
                {
                    Console.Clear();
                    Console.WriteLine("The Exile");
                    Console.WriteLine("Now it's time to fight!");
                    Console.WriteLine(this.Name + "\t\t\t\t" + "Your stats:\n" + currentHP + "/" + this.HP + "\t\t\t\t" + "Attack: " + fighterAttack + "\n\t\t\t\t\t" + fighterHp);
                    Console.WriteLine("You have won!\nPress any key to end this scene:");
                    Console.ReadKey();
                    return new int[] { fighterHp, this.xp };
                }
                Thread.Sleep(1000);
                Console.Clear();
                Console.WriteLine("The Exile");
                Console.WriteLine("Now it's time to fight!");
                Console.WriteLine(this.Name + "\t\t\t\t" + "Your stats:\n" + currentHP + "/" + this.HP + "\t\t\t\t" + "Attack: " + fighterAttack + "\n\t\t\t\t\t" + fighterHp);
                Console.WriteLine("It's the enemy's turn");
                fighterHp -= this.AP;
                if (fighterHp <= 0)
                {
                    Console.Clear();
                    Console.WriteLine("The Exile");
                    Console.WriteLine("Now it's time to fight!");
                    Console.WriteLine(this.Name + "\t\t\t\t" + "Your stats:\n" + currentHP + "/" + this.HP + "\t\t\t\t" + "Attack: " + fighterAttack + "\n\t\t\t\t\t" + fighterHp);
                    Console.WriteLine("You have lost!\nPress any key to end this scene:");
                    Console.ReadKey();
                    return new int[] { fighterHp, 0 };
                }
                Thread.Sleep(1000);
            }

            Console.WriteLine("Press any key to end this scene:");
            Console.ReadKey();
            return new int[] { fighterHp, this.xp };
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Fighter fighter = new Fighter();
            fighter.Range = 3;
            fighter.Pos = new int[] { 1, 3 };
            fighter.attack = 100;
            fighter.HP = 1000;
            fighter.XP = 0;

            Enemy enemy1 = new Enemy();
            enemy1.HP = 400;
            enemy1.AP = 60;
            enemy1.Name = "Ent";
            enemy1.xp = 100;

            string path = "map.txt";
            StreamReader sr = new StreamReader(path);
            int rows = Convert.ToInt32(sr.ReadLine());

            string[][] room = new string[rows][];
            string[] text = sr.ReadToEnd().Replace(" ", "").Split('\n');

            for (int i = 0; i < rows; i++)
            {
                string temp = text[i];
                string[] row = new string[temp.Length];
                for (int j = 0; j < row.Length; j++)
                    row[j] = temp[j].ToString();
                room[i] = row;
            }

            sr.Close();

            fighter.Temp = room[fighter.Pos[0]][fighter.Pos[1]];
            room[fighter.Pos[0]][fighter.Pos[1]] = "X";

            string map = "";
            for (int i = 0; i < room.Length; i++)
            {
                for (int j = 0; j < room[i].Length; j++)
                    map += room[i][j];
                map += "\n";
            }

            string input = "";
            do
            {
                Console.WriteLine("The Exile\n");

                if (input == "m")
                    Console.WriteLine(map);
                else
                {
                    if (input == "h")
                    {
                        Console.WriteLine("Mozgás: \"w\" (fel), \"a\" (balra), \"s\" (le), \"d\" (jobbra)");
                        Console.WriteLine("Térkép megnyitása: \"m\" ");
                        Console.WriteLine("Jelzések: \"M\" -> akadály, \" * \" -> tárgy, \"!\" -> ellenfél");
                    }
                    else if (input == "h")
                    {
                        Console.WriteLine("h - help");
                    }
                    Console.WriteLine(fighter.View(room));
                }


                if ((room[fighter.Pos[0]+1][fighter.Pos[1]]=="!") || (room[fighter.Pos[0] - 1][fighter.Pos[1]] == "!") || (room[fighter.Pos[0]][fighter.Pos[1]+1] == "!") || (room[fighter.Pos[0]][fighter.Pos[1]-1] == "!"))
                {
                    Console.WriteLine("You found yourself in front of a(n) "+enemy1.Name+" with "+enemy1.HP+" Health Points and "+enemy1.AP+" Attack Points.\nStep on the same field for combat.");
                }else if(fighter.Temp == "!")
                {
                    int[] result = enemy1.Combat(fighter.HP, fighter.attack);
                    fighter.HP = result[0];
                    fighter.XP += result[1];
                    room[fighter.Pos[0]][fighter.Pos[1]] = "0";
                    fighter.Move("d", room);
                    Console.WriteLine("The Exile");
                    Console.WriteLine(fighter.View(room));
                }
                if(!(fighter.Temp == "!"))
                {
                    input = Console.ReadKey(true).KeyChar.ToString();
                    room = fighter.Move(input, room);
                }
            } while (input != "x");
        }
    }
}
